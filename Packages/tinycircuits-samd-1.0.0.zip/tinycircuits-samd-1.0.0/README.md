# TinyCircuits TinyScreen+ and SAMD21 Support

Currently supports TinyScreen+, based on the same SAMD21 processor as the Arduino Zero.

## Installation on Arduino IDE

1. Make sure you have Arduino 1.6.6 or newer installed. If not, download from https://www.arduino.cc/en/Main/Software
2. Go to File->Preferences and in the Additional Boards Manager URLs field add https://www.tiny-circuits.com/Downloads/ArduinoBoards/package_tinycircuits_index.json
3. Click OK and restart the Arduino IDE
4. In Tools->Board->Boards Manager find the Arduino SAMD Boards and install 1.6.2- this will take a few minutes. Restart the IDE after installation.
5. In Tools->Board->Boards Manager find the TinyCircuits SAMD Boards and install the latest version. This should be very quick.
6. Restart the IDE and go to Tools->Board and select TinyScreen+ under TinyCircuits. If you're on Windows 10, Mac OSX, or Linux, jump to step 8! Windows 7 or 8? Step 7.
7. For Windows 7 and 8, it's necessary to install USB CDC drivers- we recommend Paul Stoffregen's, of PJRC(TeensyDuino) at http://pjrc.com/teensy/serial_install.exe
8. Plug in your TinyScreen+, turn it on, and select the correct Port under Tools->Port. You should be able to compile and upload the example sketch!

## License and credits

This core is a TinyCircuits-modified version of the Ardiuno SAMD21/Zero core developed by Arduino LLC in collaboration with Atmel.