# TinyCircuits AVR Core

This core is intended to be used with TinySaber, a product based on the ATtiny841. It uses the Micronucleus bootloader, portions of ATTiny Core, and the Digistump distribution of the Micronucleus uploader tool. Thank you for these contributions!

https://github.com/micronucleus/micronucleus
https://github.com/digistump/DigistumpArduino
https://github.com/SpenceKonde/ATTinyCore
